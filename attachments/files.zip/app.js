"use strict";
/* ปฏิทินเข้างาน — ตรวจจาก Google Timeline
   กะเวลาถูกล็อกตายตัว: เช้า 06:00–14:00 / บ่าย 14:00–22:00 */

const $ = (id) => document.getElementById(id);
const pad = (n) => String(n).padStart(2, "0");
const SHIFTS = [
  { key: "m", label: "กะเช้า", short: "เช้า", from: 6, to: 14, range: "06:00 – 14:00" },
  { key: "e", label: "กะบ่าย", short: "บ่าย", from: 14, to: 22, range: "14:00 – 22:00" },
];
const ICON = {
  m: '<svg viewBox="0 0 24 24" width="10" height="10" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4.5"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M4.9 19.1l1.8-1.8M17.3 6.7l1.8-1.8" fill="none"/></svg>',
  e: '<svg viewBox="0 0 24 24" width="10" height="10" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 17a7 7 0 0 1 14 0z"/><path d="M2 21h20M12 4v2.5M4.6 9.6l1.7 1.7M19.4 9.6l-1.7 1.7" fill="none"/></svg>',
};
const MIN_PIECE_H = 0.25;        // น้อยกว่า 15 นาที ถือว่าแค่ขับผ่าน
const SAMPLE_BRIDGE_MS = 45 * 60000; // จุดพิกัดห่างกันไม่เกิน 45 นาทีและอยู่ในรัศมีทั้งคู่ ถือว่าอยู่ต่อเนื่อง
const DEFAULTS = { lat: "", lng: "", radius: 45, minHours: 6, days: [1, 1, 1, 1, 1, 1, 1], theme: "dark" };

const state = {
  cfg: { ...DEFAULTS },
  store: null,             // { visits: Float64Array, samples: Float64Array, min, max, name, count }
  days: new Map(),         // key -> { m: {ms, first, last, parts}, e: {...} }
  view: new Date(),        // เดือนที่แสดง
  selected: null,
  map: null, marker: null, circle: null,
};

/* ---------- วันที่ ---------- */
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const keyToDate = (k) => new Date(`${k}T00:00:00`);
const hm = (ms) => { const d = new Date(ms); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const thaiLong = (k) => keyToDate(k).toLocaleDateString("th-TH", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
const thaiMonth = (d) => d.toLocaleDateString("th-TH", { month: "long", year: "numeric" });
const fmtH = (h) => (Math.round(h * 10) / 10).toString();

/* ---------- เก็บค่าตั้ง + ข้อมูลใน IndexedDB ---------- */
const LS = "workpulse-v2";
function loadCfg() {
  try {
    const raw = JSON.parse(localStorage.getItem(LS) || "null");
    if (raw) return { ...DEFAULTS, ...raw };
    const old = JSON.parse(localStorage.getItem("workpulse-gas") || "null"); // ย้ายค่าจากเวอร์ชันเก่า
    if (old) return { ...DEFAULTS, lat: old.lat || "", lng: old.lng || "", radius: Number(old.radius) || 45, minHours: Math.max(6, Number(old.minHours) || 6) };
  } catch {}
  return { ...DEFAULTS };
}
const saveCfg = () => { try { localStorage.setItem(LS, JSON.stringify(state.cfg)); } catch {} };

const idb = () => new Promise((res, rej) => {
  const r = indexedDB.open("workpulse", 1);
  r.onupgradeneeded = () => r.result.createObjectStore("kv");
  r.onsuccess = () => res(r.result);
  r.onerror = () => rej(r.error);
});
async function kvGet(k) {
  const db = await idb();
  return new Promise((res, rej) => { const q = db.transaction("kv").objectStore("kv").get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
}
async function kvSet(k, v) {
  const db = await idb();
  return new Promise((res, rej) => { const t = db.transaction("kv", "readwrite"); t.objectStore("kv").put(v, k); t.oncomplete = res; t.onerror = () => rej(t.error); });
}
async function kvDel(k) {
  const db = await idb();
  return new Promise((res, rej) => { const t = db.transaction("kv", "readwrite"); t.objectStore("kv").delete(k); t.oncomplete = res; t.onerror = () => rej(t.error); });
}

/* ---------- อ่านไฟล์ Timeline ---------- */
function parseLatLng(value) {
  if (value == null) return null;
  if (typeof value === "object") {
    if (value.latLng) return parseLatLng(value.latLng);
    if (typeof value.latitudeE7 === "number" && typeof value.longitudeE7 === "number") return { lat: value.latitudeE7 / 1e7, lng: value.longitudeE7 / 1e7 };
    if (typeof value.latitude === "number" && typeof value.longitude === "number") return { lat: value.latitude, lng: value.longitude };
    if (typeof value.lat === "number" && typeof value.lng === "number") return value;
    return null;
  }
  const text = String(value);
  const geo = text.match(/geo:(-?\d+\.?\d*),(-?\d+\.?\d*)/i);
  if (geo) return { lat: +geo[1], lng: +geo[2] };
  const deg = text.match(/(-?\d+\.?\d*)\s*°\s*,\s*(-?\d+\.?\d*)\s*°?/);
  if (deg) return { lat: +deg[1], lng: +deg[2] };
  const plain = text.match(/(-?\d+\.?\d*)\s*,\s*(-?\d+\.?\d*)/);
  if (plain) return { lat: +plain[1], lng: +plain[2] };
  return null;
}
function toMs(v) {
  if (v == null || v === "") return NaN;
  if (typeof v === "number") return v > 1e12 ? v : v * 1000;
  if (/^\d+$/.test(String(v))) { const n = Number(v); return n > 1e12 ? n : n * 1000; }
  return Date.parse(v);
}

/* แยกเป็น "ช่วงอยู่ที่สถานที่" (visit) กับ "จุดพิกัด" (sample) — ไม่นับช่วงเดินทางเป็นเวลาอยู่ที่ปั๊ม */
function extract(data) {
  const visits = [];   // s,e,lat,lng
  const samples = [];  // t,lat,lng
  const addVisit = (s, e, p) => { if (p && isFinite(s) && isFinite(e) && e > s) visits.push(s, e, p.lat, p.lng); };
  const addSample = (t, p) => { if (p && isFinite(t)) samples.push(t, p.lat, p.lng); };

  const walk = (node) => {
    if (!node || typeof node !== "object") return;
    if (Array.isArray(node)) { for (const x of node) walk(x); return; }

    if (node.latitudeE7 != null && (node.timestamp || node.timestampMs)) {           // Records.json
      addSample(toMs(node.timestamp || node.timestampMs), parseLatLng(node)); return;
    }
    if (node.visit) {                                                                  // รูปแบบใหม่
      addVisit(toMs(node.startTime), toMs(node.endTime), parseLatLng(node.visit.topCandidate?.placeLocation)); return;
    }
    if (node.placeVisit) {                                                             // รูปแบบเก่า
      const v = node.placeVisit, d = v.duration || {};
      const loc = v.location?.latitudeE7 != null ? v.location : v.centerLatE7 != null ? { latitudeE7: v.centerLatE7, longitudeE7: v.centerLngE7 } : null;
      addVisit(toMs(d.startTimestamp || d.startTimestampMs), toMs(d.endTimestamp || d.endTimestampMs), parseLatLng(loc)); return;
    }
    if (node.activity || node.activitySegment) return;                                 // การเดินทาง ข้าม
    if (Array.isArray(node.timelinePath)) {
      const base = toMs(node.startTime);
      for (const p of node.timelinePath) {
        const t = p.time ? toMs(p.time) : base + (Number(p.durationMinutesOffsetFromStartTime) || 0) * 60000;
        addSample(t, parseLatLng(p.point));
      }
      return;
    }
    for (const v of Object.values(node)) if (v && typeof v === "object") walk(v);
  };
  walk(data);

  // เรียงจุดพิกัดตามเวลา
  const n = samples.length / 3;
  const idx = new Uint32Array(n); for (let i = 0; i < n; i++) idx[i] = i;
  idx.sort((a, b) => samples[a * 3] - samples[b * 3]);
  const sorted = new Float64Array(n * 3);
  for (let i = 0; i < n; i++) { const o = idx[i] * 3; sorted[i * 3] = samples[o]; sorted[i * 3 + 1] = samples[o + 1]; sorted[i * 3 + 2] = samples[o + 2]; }

  let min = Infinity, max = -Infinity;
  for (let i = 0; i < visits.length; i += 4) { if (visits[i] < min) min = visits[i]; if (visits[i + 1] > max) max = visits[i + 1]; }
  if (n) { if (sorted[0] < min) min = sorted[0]; if (sorted[(n - 1) * 3] > max) max = sorted[(n - 1) * 3]; }
  return { visits: Float64Array.from(visits), samples: sorted, min, max, count: visits.length / 4 + n };
}
function extractPlaces(data) {
  return (data?.userLocationProfile?.frequentPlaces || [])
    .map((p) => ({ label: p.label || "สถานที่ที่ไปบ่อย", loc: parseLatLng(p.placeLocation || p) }))
    .filter((p) => p.loc);
}

/* ---------- วิเคราะห์ ---------- */
function haversine(aLat, aLng, bLat, bLng) {
  const R = 6371000, r = Math.PI / 180;
  const dLat = (bLat - aLat) * r, dLng = (bLng - aLng) * r;
  const n = Math.sin(dLat / 2) ** 2 + Math.cos(aLat * r) * Math.cos(bLat * r) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(n)));
}

function analyze(store, cfg) {
  const lat = parseFloat(cfg.lat), lng = parseFloat(cfg.lng), R = Number(cfg.radius) || 45;
  const pieces = [];
  const V = store.visits;
  for (let i = 0; i < V.length; i += 4) if (haversine(lat, lng, V[i + 2], V[i + 3]) <= R) pieces.push([V[i], V[i + 1]]);
  const S = store.samples;
  let prevIn = false, prevT = 0;
  for (let i = 0; i < S.length; i += 3) {
    const t = S[i], inn = haversine(lat, lng, S[i + 1], S[i + 2]) <= R;
    if (inn && prevIn && t > prevT && t - prevT <= SAMPLE_BRIDGE_MS) pieces.push([prevT, t]);
    prevIn = inn; prevT = t;
  }
  // รวมช่วงที่ซ้อนกัน กันนับเวลาซ้ำ
  pieces.sort((a, b) => a[0] - b[0]);
  const merged = [];
  for (const p of pieces) {
    const last = merged[merged.length - 1];
    if (last && p[0] <= last[1]) last[1] = Math.max(last[1], p[1]); else merged.push([p[0], p[1]]);
  }
  // ตัดเข้ากะเช้า/บ่ายของแต่ละวัน
  const days = new Map();
  for (const [s, e] of merged) {
    const d = new Date(s); d.setHours(0, 0, 0, 0);
    for (let guard = 0; d.getTime() < e && guard < 8; guard++, d.setDate(d.getDate() + 1)) {
      const key = ymd(d);
      for (const sh of SHIFTS) {
        const ws = new Date(d); ws.setHours(sh.from, 0, 0, 0);
        const we = new Date(d); we.setHours(sh.to, 0, 0, 0);
        const a = Math.max(s, ws.getTime()), b = Math.min(e, we.getTime());
        if (b <= a) continue;
        const rec = days.get(key) || {};
        const r = rec[sh.key] || (rec[sh.key] = { ms: 0, first: a, last: b, parts: [] });
        r.ms += b - a; r.first = Math.min(r.first, a); r.last = Math.max(r.last, b); r.parts.push([a, b]);
        days.set(key, rec);
      }
    }
  }
  return days;
}

/* สถานะของวันหนึ่ง ๆ */
function dayInfo(key) {
  const minH = Math.max(6, Number(state.cfg.minHours) || 6);
  const rec = state.days.get(key) || {};
  const date = keyToDate(key);
  const todayKey = ymd(new Date());
  const hasData = !!state.store && state.days !== null && state.cfg.lat !== "" && state.cfg.lng !== "";
  const minKey = hasData ? ymd(new Date(state.store.min)) : null;
  const maxKey = hasData ? ymd(new Date(state.store.max)) : null;
  const inRange = hasData && key >= minKey && key <= maxKey && key <= todayKey;
  const shifts = {};
  let okCount = 0, warnAny = false, totalMs = 0;
  for (const sh of SHIFTS) {
    const r = rec[sh.key];
    const h = r ? r.ms / 3600000 : 0;
    const st = h >= minH ? "ok" : h >= MIN_PIECE_H ? "warn" : "none";
    if (st === "ok") okCount++;
    if (st === "warn") warnAny = true;
    if (r) totalMs += r.ms;
    shifts[sh.key] = { st, h, rec: r };
  }
  const workDay = !!state.cfg.days[date.getDay()];
  let kind;
  if (!inRange) kind = "out";
  else if (okCount) kind = "worked";
  else if (!workDay) kind = "off";
  else if (warnAny) kind = "partial";
  else kind = "absent";
  return { key, kind, shifts, okCount, hours: totalMs / 3600000, inRange, minH };
}

/* ---------- วาดปฏิทิน ---------- */
function renderCalendar() {
  const y = state.view.getFullYear(), m = state.view.getMonth();
  $("monthTitle").textContent = thaiMonth(state.view);
  const startPad = new Date(y, m, 1).getDay();
  const dim = new Date(y, m + 1, 0).getDate();
  const rows = Math.ceil((startPad + dim) / 7);
  $("grid").style.setProperty("--rows", rows);
  const todayKey = ymd(new Date());
  let html = "", okDays = 0, cm = 0, ce = 0, hours = 0, warn = 0, bad = 0;

  for (let i = 0; i < startPad; i++) html += '<div class="cell blank"></div>';
  for (let d = 1; d <= dim; d++) {
    const key = `${y}-${pad(m + 1)}-${pad(d)}`;
    const info = dayInfo(key);
    if (info.inRange) {
      hours += info.hours;
      if (info.okCount) okDays++;
      if (info.shifts.m.st === "ok") cm++;
      if (info.shifts.e.st === "ok") ce++;
      if (info.kind === "partial") warn++;
      if (info.kind === "absent") bad++;
    }
    const cls = ["cell", info.kind, key === todayKey ? "today" : "", key === state.selected ? "sel" : ""].join(" ");
    let slots = "";
    if (info.inRange && info.kind !== "off") {
      slots = '<div class="slots">' + SHIFTS.map((sh) => {
        const st = info.shifts[sh.key].st;
        return `<span class="slot ${sh.key} ${st}">${st === "none" ? "" : ICON[sh.key] + sh.short}</span>`;
      }).join("") + "</div>";
    }
    html += `<button type="button" class="${cls}" data-day="${key}"><span class="n">${d}</span>${slots}</button>`;
  }
  $("grid").innerHTML = html;

  $("stDays").textContent = okDays;
  $("stM").textContent = cm;
  $("stE").textContent = ce;
  $("stH").textContent = fmtH(hours);
  $("lgWarn").textContent = warn;
  $("lgBad").textContent = bad;
  $("empty").hidden = !!state.store && state.cfg.lat !== "";
  $("csv").disabled = !state.store;
}

function showDay(key) {
  state.selected = key;
  const info = dayInfo(key);
  $("dayTitle").textContent = thaiLong(key);
  const sub = { worked: "ไปทำงาน", partial: "อยู่ที่ปั๊มไม่ครบเกณฑ์", absent: "ไม่พบที่ปั๊ม", off: "วันหยุดที่ตั้งไว้", out: "ไม่มีข้อมูลของวันนี้" }[info.kind];
  $("daySub").textContent = sub;
  let html = "";
  for (const sh of SHIFTS) {
    const s = info.shifts[sh.key];
    const badge = !info.inRange ? ["mute", "ไม่มีข้อมูล"] : s.st === "ok" ? ["ok", "ไปทำงาน"] : s.st === "warn" ? ["warn", "ไม่ครบเกณฑ์"] : ["none", "ไม่พบ"];
    html += `<div class="shift-card ${sh.key} ${info.inRange ? s.st : ""}">
      <div class="sc-head"><div><b>${sh.label}</b><small>${sh.range} น.</small></div><span class="badge ${badge[0]}">${badge[1]}</span></div>
      <div class="sc-grid">
        <div><span>เข้า</span><b>${s.rec ? hm(s.rec.first) : "—"}</b></div>
        <div><span>ออก</span><b>${s.rec ? hm(s.rec.last) : "—"}</b></div>
        <div><span>อยู่ที่ปั๊ม</span><b>${s.rec ? fmtH(s.h) + " ชม." : "—"}</b></div>
      </div>
      ${s.rec ? `<div class="parts">${s.rec.parts.map(([a, b]) => `<span>${hm(a)}–${hm(b)}</span>`).join("")}</div>` : ""}
    </div>`;
  }
  html += `<p class="day-note">นับว่าไปทำงานเมื่ออยู่ในรัศมี ${state.cfg.radius} ม. รอบปั๊มอย่างน้อย ${info.minH} ชั่วโมงในกะนั้น</p>`;
  $("dayBody").innerHTML = html;
  openSheet("daySheet");
  renderCalendar();
}

/* ---------- ชีต ---------- */
function openSheet(id) { const el = $(id); el.classList.add("open"); el.setAttribute("aria-hidden", "false"); if (id === "setSheet") initMap(); }
function closeSheet(id) { const el = $(id); el.classList.remove("open"); el.setAttribute("aria-hidden", "true"); }
document.querySelectorAll(".backdrop").forEach((b) => b.addEventListener("click", (e) => { if (e.target === b) closeSheet(b.id); }));
document.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => closeSheet(b.dataset.close)));

let toastTimer;
function toast(msg) { const t = $("toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 2200); }
function showError(msg) { const e = $("error"); e.textContent = msg; e.hidden = !msg; }

/* ---------- แผนที่ ---------- */
function initMap() {
  if (state.map) { setTimeout(() => state.map.invalidateSize(), 250); return; }
  if (typeof L === "undefined") { $("mapOff").hidden = false; return; }
  state.map = L.map("map", { zoomControl: false }).setView([13.7563, 100.5018], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "&copy; OpenStreetMap" }).addTo(state.map);
  state.map.on("click", (e) => setWork(e.latlng.lat, e.latlng.lng, false));
  const lat = parseFloat($("lat").value), lng = parseFloat($("lng").value);
  if (isFinite(lat) && isFinite(lng)) setWork(lat, lng, true);
  setTimeout(() => state.map.invalidateSize(), 250);
}
function setWork(lat, lng, pan = true) {
  $("lat").value = Number(lat).toFixed(6);
  $("lng").value = Number(lng).toFixed(6);
  if (!state.map) return;
  const ll = [lat, lng], r = Number($("radius").value) || 45;
  if (state.marker) state.marker.setLatLng(ll); else state.marker = L.marker(ll).addTo(state.map);
  if (state.circle) state.circle.setLatLng(ll).setRadius(r); else state.circle = L.circle(ll, { radius: r, color: "#8b5cf6", fillOpacity: 0.2 }).addTo(state.map);
  if (pan) state.map.setView(ll, 18);
}
$("radius").addEventListener("input", () => {
  $("radiusLabel").textContent = `${$("radius").value} ม.`;
  if (state.circle) state.circle.setRadius(Number($("radius").value));
});
["lat", "lng"].forEach((id) => $(id).addEventListener("change", () => {
  const lat = parseFloat($("lat").value), lng = parseFloat($("lng").value);
  if (isFinite(lat) && isFinite(lng)) setWork(lat, lng);
}));
$("searchBtn").addEventListener("click", async () => {
  const q = $("search").value.trim(); if (!q) return;
  try {
    const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q)}`);
    const data = await res.json();
    if (!data[0]) return showError("ไม่พบสถานที่ที่ค้นหา");
    showError(""); setWork(+data[0].lat, +data[0].lon);
  } catch { showError("ค้นหาไม่ได้ ตรวจสอบอินเทอร์เน็ตหรือใส่พิกัดเอง"); }
});

/* ---------- ไฟล์ ---------- */
async function readFile(file) {
  showError("");
  $("fileInfo").textContent = "กำลังอ่านไฟล์…";
  let data;
  try { data = JSON.parse(await file.text()); } catch { throw new Error("อ่านไฟล์ไม่ได้ ต้องเป็นไฟล์ JSON ที่ส่งออกจาก Google Timeline"); }
  const store = extract(data);
  if (!store.count) throw new Error("ไม่พบข้อมูลตำแหน่งในไฟล์นี้ ลองส่งออก Timeline ใหม่");
  store.name = file.name;
  state.store = store;
  await kvSet("store", store);
  $("fileName").textContent = file.name;
  $("fileInfo").textContent = `${store.count.toLocaleString("th-TH")} รายการ · ${thaiShort(store.min)} – ${thaiShort(store.max)}`;
  const box = $("detectedPlaces"); box.innerHTML = "";
  for (const p of extractPlaces(data)) {
    const b = document.createElement("button");
    b.type = "button"; b.textContent = p.label;
    b.addEventListener("click", () => setWork(p.loc.lat, p.loc.lng));
    box.appendChild(b);
  }
  $("csv").disabled = false;
}
const thaiShort = (ms) => new Date(ms).toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "2-digit" });
$("file").addEventListener("change", (e) => {
  const f = e.target.files[0];
  if (f) readFile(f).then(() => { if ($("lat").value && $("lng").value) runAnalysis(); }).catch((err) => { showError(err.message); $("fileInfo").textContent = "ลองใหม่อีกครั้ง"; });
});

/* ---------- ประมวลผล ---------- */
function readForm() {
  const days = [0, 0, 0, 0, 0, 0, 0];
  document.querySelectorAll("#days input").forEach((el) => { days[Number(el.value)] = el.checked ? 1 : 0; });
  state.cfg = {
    ...state.cfg,
    lat: $("lat").value, lng: $("lng").value,
    radius: Number($("radius").value) || 45,
    minHours: Math.max(6, Math.min(8, Number($("hVal").textContent) || 6)),
    days,
  };
}
function writeForm() {
  const c = state.cfg;
  $("lat").value = c.lat; $("lng").value = c.lng;
  $("radius").value = c.radius; $("radiusLabel").textContent = `${c.radius} ม.`;
  $("hVal").textContent = c.minHours;
  document.querySelectorAll("#days input").forEach((el) => { el.checked = !!c.days[Number(el.value)]; });
}
function runAnalysis() {
  readForm();
  showError("");
  if (!state.store) { showError("ยังไม่ได้เลือกไฟล์ Timeline"); return false; }
  const lat = parseFloat(state.cfg.lat), lng = parseFloat(state.cfg.lng);
  if (!isFinite(lat) || !isFinite(lng)) { showError("ปักหมุดจุดปั๊มบนแผนที่ หรือใส่ละติจูด/ลองจิจูดก่อน"); return false; }
  state.days = analyze(state.store, state.cfg);
  saveCfg();
  renderCalendar();
  return true;
}
$("run").addEventListener("click", () => {
  if (runAnalysis()) { closeSheet("setSheet"); toast("บันทึกและประมวลผลแล้ว"); }
});
$("hMinus").addEventListener("click", () => { $("hVal").textContent = Math.max(6, Number($("hVal").textContent) - 0.5); });
$("hPlus").addEventListener("click", () => { $("hVal").textContent = Math.min(8, Number($("hVal").textContent) + 0.5); });

/* ---------- ปุ่มต่าง ๆ ---------- */
$("grid").addEventListener("click", (e) => {
  const c = e.target.closest(".cell[data-day]");
  if (c) showDay(c.dataset.day);
});
function gotoMonth(delta) { state.view = new Date(state.view.getFullYear(), state.view.getMonth() + delta, 1); renderCalendar(); }
$("prevMonth").addEventListener("click", () => gotoMonth(-1));
$("nextMonth").addEventListener("click", () => gotoMonth(1));
$("todayBtn").addEventListener("click", () => { const t = new Date(); state.view = new Date(t.getFullYear(), t.getMonth(), 1); state.selected = ymd(t); renderCalendar(); });
$("gearBtn").addEventListener("click", () => openSheet("setSheet"));
$("emptyBtn").addEventListener("click", () => openSheet("setSheet"));
$("jumpBtn").addEventListener("click", () => {
  const v = $("jumpDate").value || ymd(new Date());
  const d = keyToDate(v);
  state.view = new Date(d.getFullYear(), d.getMonth(), 1);
  closeSheet("setSheet");
  showDay(v);
});

// ปัดซ้าย/ขวาเพื่อเปลี่ยนเดือน
let tx = 0, ty = 0;
$("cal").addEventListener("touchstart", (e) => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
$("cal").addEventListener("touchend", (e) => {
  const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
  if (Math.abs(dx) > 60 && Math.abs(dy) < 45) gotoMonth(dx < 0 ? 1 : -1);
}, { passive: true });

/* ธีม */
function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  $("themeColor").setAttribute("content", t === "dark" ? "#070c18" : "#e9f0fa");
}
$("themeBtn").addEventListener("click", () => {
  state.cfg.theme = state.cfg.theme === "dark" ? "light" : "dark";
  applyTheme(state.cfg.theme); saveCfg();
});

/* CSV */
$("csv").addEventListener("click", () => {
  if (!state.store || !state.days) return;
  const from = new Date(state.store.min); from.setHours(0, 0, 0, 0);
  const to = new Date(Math.min(state.store.max, Date.now()));
  const head = ["วันที่", "สถานะ", "เช้า-เข้า", "เช้า-ออก", "เช้า-ชม.", "บ่าย-เข้า", "บ่าย-ออก", "บ่าย-ชม."];
  const name = { worked: "ไปทำงาน", partial: "ไม่ครบเกณฑ์", absent: "ไม่พบ", off: "วันหยุด", out: "" };
  const lines = [head.join(",")];
  for (const d = new Date(from); d <= to; d.setDate(d.getDate() + 1)) {
    const info = dayInfo(ymd(d));
    const cols = [info.key, name[info.kind]];
    for (const sh of SHIFTS) {
      const r = info.shifts[sh.key].rec;
      cols.push(r ? hm(r.first) : "", r ? hm(r.last) : "", r ? (r.ms / 3600000).toFixed(2) : "");
    }
    lines.push(cols.join(","));
  }
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8" }));
  a.download = "work-attendance.csv"; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
});

$("wipe").addEventListener("click", async () => {
  if (!confirm("ล้างไฟล์ Timeline และผลทั้งหมดที่เก็บไว้ในเครื่อง?")) return;
  await kvDel("store").catch(() => {});
  state.store = null; state.days = new Map();
  $("fileName").textContent = "เลือกไฟล์ JSON จากมือถือ";
  $("fileInfo").textContent = "ประมวลผลในเครื่อง ไม่ถูกส่งไปที่ไหน";
  renderCalendar(); toast("ล้างข้อมูลแล้ว");
});

/* ---------- เริ่มต้น ---------- */
(async function init() {
  state.cfg = loadCfg();
  applyTheme(state.cfg.theme);
  writeForm();
  const t = new Date();
  state.view = new Date(t.getFullYear(), t.getMonth(), 1);
  try {
    const store = await kvGet("store");
    if (store && store.visits) {
      state.store = store;
      $("fileName").textContent = store.name || "ไฟล์ Timeline";
      $("fileInfo").textContent = `${store.count.toLocaleString("th-TH")} รายการ · ${thaiShort(store.min)} – ${thaiShort(store.max)}`;
      if (state.cfg.lat !== "" && state.cfg.lng !== "") {
        state.days = analyze(store, state.cfg);
        if (ymd(t) > ymd(new Date(store.max))) { const m = new Date(store.max); state.view = new Date(m.getFullYear(), m.getMonth(), 1); }
      }
    }
  } catch {}
  renderCalendar();
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("sw.js").catch(() => {});
})();
